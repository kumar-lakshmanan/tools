# # djangotemplates/example/views.py
# from django.shortcuts import render
# from django.views.generic import TemplateView # Import TemplateView
#
# # Add the two views we have been talking about  all this time :)
# class HomePageView(TemplateView):
#     template_name = "index.html"
#
#
# class AboutPageView(TemplateView):
#     template_name = "about.html"


from django.http import HttpResponse
from django.template import loader

def HomePageView(request):
    template = loader.get_template('index.html')
    context = {
      'mymembers': 'someinfgo',
    }    
    return HttpResponse(template.render(context, request))

def AboutPageView(request):
    template = loader.get_template('about.html')
    context = {
      'mymembers': 'someinfgo',
    }    
    return HttpResponse(template.render(context, request))
from django.urls import path, include
from pocapp import views

urlpatterns = [
    path('home/', views.HomePageView, name='home'),
    path('about/', views.AboutPageView, name='about')
]

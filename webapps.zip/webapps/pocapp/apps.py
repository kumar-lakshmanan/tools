from django.apps import AppConfig


class PocappConfig(AppConfig):
    name = 'pocapp'

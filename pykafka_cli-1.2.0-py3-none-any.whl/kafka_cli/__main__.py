from .app import Kafka

if __name__ == '__main__':
    Kafka.run()